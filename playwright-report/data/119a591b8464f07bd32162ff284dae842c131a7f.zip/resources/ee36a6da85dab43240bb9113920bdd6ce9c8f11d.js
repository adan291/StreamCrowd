
function pLPCommand(c, a1, a2, a3, a4) {
parent.window["pLPCommand1"] && parent.window["pLPCommand1"](c, a1, a2, a3, a4);
}
function pRTLPCB(pN, data) {
parent.window["pRTLPCB1"] && parent.window["pRTLPCB1"](pN, data);
}
         pLPCommand('start','2014100','w6rEPwUsWS');
pRTLPCB(0,[{"t":"c","d":{"t":"h","d":{"ts":1766753943903,"v":"5","h":"s-gke-euw1-nssi1-9.europe-west1.firebasedatabase.app","s":"sw8LnfbmkeevUDTLpdd6E3IgX09Isbvo"}}}]);
