pRTLPCB(4,[{"t":"d","d":{"r":3,"b":{"s":"ok","d":""}}},{"t":"c","d":{"t":"n","d":null}}]);
pLPCommand('close',4);
